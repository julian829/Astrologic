package com.example.Astrologic;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AstrologicApplicationTests {

	@Test
	void contextLoads() {
	}

}
